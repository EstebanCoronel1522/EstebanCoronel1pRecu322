package primerparcialrecitales;


public enum EstiloMusical {
    TECHNO,
    HOUSE;
}
