package primerparcialrecitales;


public class Solistas extends Presentacion implements Tocable, Animable{
    private InstrumentoMusical instrumentoMusical;

    public Solistas(InstrumentoMusical instrumentoPrincipal, String nombre, String predio, TipoEscenario tipoEscenario) {
        super(nombre, predio, tipoEscenario);
        this.instrumentoMusical = instrumentoPrincipal;
    }

    public InstrumentoMusical getInstrumentoMusical() {
        return instrumentoMusical;
    }

    @Override
    public void tocar() {
        System.out.println("La banda " + this.getNombre());
    }

    @Override
    public void animar() {
        System.out.println("La banda " + this.getNombre() + "Esta animando");

    }

    @Override
    public String toString() {
        return "Solistas{" + super.toString() + "instrumentoMusical=" + instrumentoMusical + '}';
    }

  
}
    