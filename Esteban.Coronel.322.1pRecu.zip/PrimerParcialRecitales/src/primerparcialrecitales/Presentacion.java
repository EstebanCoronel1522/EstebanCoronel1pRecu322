package primerparcialrecitales;


public class Presentacion {
    private String nombre;
    private String predio;
    private TipoEscenario tipoEscenario;
      
    public Presentacion(String nombre, String predio, TipoEscenario tipoEscenario) {
        this.nombre = nombre;
        this.predio = predio;
        this.tipoEscenario = tipoEscenario;
    }
    

    public String getNombre() {
        return nombre;
    }

    public String getPredio() {
        return predio;
    }

    public TipoEscenario getTipoEscenario() {
        return tipoEscenario;
    }
     public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Presentacion)) return false;
        Presentacion presentacion = (Presentacion) o;
        return nombre.equals(presentacion.nombre) &&
               tipoEscenario.equals(presentacion.tipoEscenario);
     }
    protected String mostrar(){
        StringBuilder sb= new StringBuilder();
        sb.append ("Nombre banda: " + this.getNombre() + " ");
        sb.append ("Predio: " + this.getPredio() + " ");
        sb.append ("Escenario: " + this.getTipoEscenario() + " ");
        return(sb.toString());

  
}
    @Override
    public String toString(){
        return this.mostrar();
    }
    
}