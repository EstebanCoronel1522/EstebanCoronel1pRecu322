package primerparcialrecitales;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Recital {

    List<Presentacion> listaEscenario = new ArrayList<>();

    public void agregarPresentacion(Presentacion presentacion) throws DatoPresentacionExistente {
        if (listaEscenario.contains(presentacion)) {
            throw new DatoPresentacionExistente("Ya existe esta banda " + presentacion.getNombre()
                    + " en el escenario " + presentacion.getTipoEscenario());
        }
        listaEscenario.add(presentacion);
        System.out.println("Presentacion " + presentacion.getNombre() + " agregado ");
    }

    public void mostrarPresentacion() {
        if (listaEscenario.isEmpty()) {
            System.out.println("No se encuentran recitales registrados ");
        } else {
            for (Presentacion p : listaEscenario) {
                System.out.println(p.toString());
            }
        }
    }

    public void tocarEnVivo() {
        if (listaEscenario.isEmpty()) {
            System.out.println("No hay presentaciones registradas.");
        } else {
            for (Presentacion presentacion : listaEscenario) {

                if (presentacion instanceof Bandas) {
                    System.out.println(presentacion.getNombre() + " esta tocando en vivo");
                } else {
                    System.out.println("La presentacion " + presentacion.getNombre() + " no puede tocar en vivo");
                }
            }
        }
    }

    public void animarPublico() {
        if (listaEscenario.isEmpty()) {
            System.out.println("No hay presentaciones registradas.");
        } else {
            for (Presentacion presentacion : listaEscenario) {
                if (presentacion instanceof Bandas) {
                    System.out.println("La presentacion no puede animar al publico ");
                } else {
                    System.out.println(presentacion.getNombre() + "esta animando al publico");
                }
            }
        }
    }

    public ArrayList<Presentacion> filtrarPorTipoEscenario(TipoEscenario tipo) {
        ArrayList<Presentacion> listaActualizada = new ArrayList<>();
        for (Presentacion p : listaEscenario) {
            if (p.getTipoEscenario().equals(tipo)) {
                listaActualizada.add(p);
                System.out.println(p.toString());
            }
        }
        return listaActualizada;
    }

    public void eliminarPresentacionesPorTipo(TipoEscenario tipo) {
        Iterator<Presentacion> it = listaEscenario.iterator();
        while (it.hasNext()) {
            Presentacion p = it.next();
            if (p.getTipoEscenario().equals(tipo)) {
                it.remove();

            }
        }
       
    }
}