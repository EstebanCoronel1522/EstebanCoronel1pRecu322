
package primerparcialrecitales;

public interface Tocable {
    void tocar();
}
