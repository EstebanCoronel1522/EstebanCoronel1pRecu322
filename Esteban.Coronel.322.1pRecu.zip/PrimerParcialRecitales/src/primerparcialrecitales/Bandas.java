
package primerparcialrecitales;


public class Bandas extends Presentacion implements Tocable{
    private int cantidadIntegrantes;
    private static final int CANT_MAX = 5;
    private static final int CANT_MIN = 1;

    public Bandas(int cantidadIntegrantes, String nombre, String predio, TipoEscenario tipoEscenario) {
        super(nombre, predio, tipoEscenario);
        this.cantidadIntegrantes = cantidadIntegrantes;
        if (cantidadIntegrantes > CANT_MAX || cantidadIntegrantes< CANT_MIN){
               throw new IllegalArgumentException (getNombre()+": " + "Integrantes fuera de rango");
           }
    }
        public int getCantidadIntegrantes() {
        return cantidadIntegrantes;
    }

    @Override
    public void tocar() {
        System.out.println("La banda: "+ this.getNombre() + "esta tocando en vivo ");
    }
    
    @Override
    public String toString() {
        return "Bandas{" + super.toString() + "cantidadIntegrantes=" + cantidadIntegrantes + '}';
    }

  
}
