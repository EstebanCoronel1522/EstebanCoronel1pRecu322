package primerparcialrecitales;

public class PrimerParcialRecitales {

    public static void main(String[] args) throws DatoPresentacionExistente {

        Recital recital = new Recital();

        System.out.println("=== AGREGANDO PRESENTACIONES ===");

        try {
            recital.agregarPresentacion(new Bandas(5, "Los Relampagos", "Escenario Principal", TipoEscenario.EXTERIOR));
            recital.agregarPresentacion(new Bandas(5, "Los Relampagos", "Escenario Principal", TipoEscenario.EXTERIOR));
        }catch (DatoPresentacionExistente e){
            System.out.println(e.getMessage());
        }
            try{
            recital.agregarPresentacion(new Solistas(InstrumentoMusical.GUITARRA, "Maria Luna", "Escenario Secundario", TipoEscenario.INTERIOR));
            recital.agregarPresentacion(new Solistas(InstrumentoMusical.GUITARRA, "Maria Luna", "Escenario Secundario", TipoEscenario.INTERIOR));
           }catch (DatoPresentacionExistente e){
            System.out.println(e.getMessage());
        }
            try{
            recital.agregarPresentacion(new Djs( EstiloMusical.TECHNO ,"TechnoMax", "Carpa Electronica", TipoEscenario.INTERIOR));
            recital.agregarPresentacion(new Djs( EstiloMusical.TECHNO ,"TechnoMax", "Carpa Electronica", TipoEscenario.INTERIOR));
              }catch (DatoPresentacionExistente e){
            System.out.println(e.getMessage());
        
          
        System.out.println("\n=== MOSTRAR PRESENTACIONES ===");
        recital.mostrarPresentacion();

        System.out.println("\n=== TOCAR EN VIVO ===");
        recital.tocarEnVivo();

        System.out.println("\n=== ANIMAR AL PUBLICO ===");
        recital.animarPublico();

        System.out.println("\n=== FILTRAR POR TIPO DE ESCENARIO (INTERIOR) ===");
        recital.filtrarPorTipoEscenario(TipoEscenario.INTERIOR);

        System.out.println("\n=== PRESENTACIONES TRAS ELIMINAR ===");
        recital.mostrarPresentacion();
    }
}
}
