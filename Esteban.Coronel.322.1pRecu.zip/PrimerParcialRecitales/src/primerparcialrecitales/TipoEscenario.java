package primerparcialrecitales;


public enum TipoEscenario {
    INTERIOR,
    EXTERIOR;
}
