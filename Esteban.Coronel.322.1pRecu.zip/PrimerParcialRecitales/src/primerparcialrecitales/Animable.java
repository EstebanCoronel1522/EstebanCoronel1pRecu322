package primerparcialrecitales;


public interface Animable {
    void animar();
}
