package primerparcialrecitales;


public class Djs extends Presentacion implements Animable{
    private EstiloMusical estiloMusical;

    public Djs(EstiloMusical estiloMusical, String nombre, String predio, TipoEscenario tipoEscenario) {
        super(nombre, predio, tipoEscenario);
        this.estiloMusical = estiloMusical;
    }

    public EstiloMusical getEstiloMusical() {
        return estiloMusical;
    }

    @Override
    public void animar() {
        System.out.println("La banda " + this.getNombre() + "Recibio felicitaciones");
    }

    @Override
    public String toString() {
        return "Djs{" + super.toString() + "estiloMusical=" + estiloMusical + '}';
    }
    
}
