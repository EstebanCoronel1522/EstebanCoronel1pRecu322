package primerparcialrecitales;


public enum InstrumentoMusical {
 GUITARRA,
 BATERIA;
}
