package primerparcialrecitales;


public class DatoPresentacionExistente extends Exception {
    private static final String MESSAGE = " ";
    
    public DatoPresentacionExistente(){
        this(MESSAGE);
        
    }
    public DatoPresentacionExistente (String mensaje){
        super(mensaje);
    }
}


